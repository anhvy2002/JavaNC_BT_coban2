
package BT;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class GiayDAO {
    public boolean in(Giay gi) throws Exception{
        String sql = "INSERT INTO QLGiay(maGiay, tenGiay, thuongHieu, nhomGiay, giaBan, soLuong) VALUES(?, ?, ?, ?, ?, ?)";
        try(
            Connection con = KetNoiSQL.opConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            )
        {
            ps.setInt(1, gi.getMaGiay());
            ps.setString(2, gi.getTenGiay());
            ps.setString(3, gi.getThuongHieu());
            ps.setString(4, gi.getNhomGiay());
            ps.setDouble(5, gi.getGiaBan());
            ps.setInt(6, gi.getSoLuong());
            
            return ps.executeUpdate() > 0;
        }
    }
    
    public Giay tim(int maGiay) throws Exception{
        String sql = "SELECT * FROM QLGiay WHERE maGiay = ?";
        try(
                Connection con = KetNoiSQL.opConnection();
                PreparedStatement ps = con.prepareStatement(sql);
            ){
                ps.setInt(1, maGiay);
                ResultSet rs = ps.executeQuery();
                
                if(rs.next()){
                    Giay g = new Giay();
                    g.setMaGiay(rs.getInt("maGiay"));
                    g.setTenGiay(rs.getString("tenGiay"));
                    g.setThuongHieu(rs.getString("thuongHieu"));
                    g.setNhomGiay(rs.getString("nhomGiay"));
                    g.setGiaBan(rs.getDouble("giaBan"));
                    g.setSoLuong(rs.getInt("soLuong"));   
                    
                    return g;
                }
                return null;
            }
    }
    public boolean sua(Giay gi) throws Exception{
        String sql = "UPDATE QLGiay SET tenGiay = ?, thuongHieu = ?, nhomGiay = ?, giaBan = ?, soLuong = ? where maGiay = ?";
        try(
            Connection con = KetNoiSQL.opConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            )
        {
            ps.setInt(6, gi.getMaGiay());
            ps.setString(1, gi.getTenGiay());
            ps.setString(2, gi.getThuongHieu());
            ps.setString(3, gi.getNhomGiay());
            ps.setDouble(4, gi.getGiaBan());
            ps.setInt(5, gi.getSoLuong());
            
            return ps.executeUpdate() > 0;
        }
    }
    public boolean xoa(int maGiay) throws Exception{
        String sql = "DELETE FROM QLGiay WHERE maGiay = ?";
        try(
            Connection con = KetNoiSQL.opConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            )
        {
            ps.setInt(1, maGiay);
            
            return ps.executeUpdate() > 0;
        }
    }
}
