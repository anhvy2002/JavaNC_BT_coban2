/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BT;

/**
 *
 * @author DELL
 */
public class Giay {
    private int maGiay;
    private String tenGiay;
    private String thuongHieu;
    private String nhomGiay;
    private double giaBan;
    private int soLuong;
    
    public Giay() {
    
    }
    
    public Giay(int maGiay, String tenGiay, String thuongHieu, String nhomGiay, double giaBan, int soLuong) {
        this.maGiay = maGiay;
        this.tenGiay = tenGiay;
        this.thuongHieu = thuongHieu;
        this.nhomGiay = nhomGiay;
        this.giaBan = giaBan;
        this.soLuong = soLuong;
    }

    /**
     * @return the maGiay
     */
    public int getMaGiay() {
        return maGiay;
    }

    /**
     * @param maGiay the maGiay to set
     */
    public void setMaGiay(int maGiay) {
        this.maGiay = maGiay;
    }

    /**
     * @return the tenGiay
     */
    public String getTenGiay() {
        return tenGiay;
    }

    /**
     * @param tenGiay the tenGiay to set
     */
    public void setTenGiay(String tenGiay) {
        this.tenGiay = tenGiay;
    }

    /**
     * @return the thuongHieu
     */
    public String getThuongHieu() {
        return thuongHieu;
    }

    /**
     * @param thuongHieu the thuongHieu to set
     */
    public void setThuongHieu(String thuongHieu) {
        this.thuongHieu = thuongHieu;
    }

    /**
     * @return the nhomGiay
     */
    public String getNhomGiay() {
        return nhomGiay;
    }

    /**
     * @param nhomGiay the nhomGiay to set
     */
    public void setNhomGiay(String nhomGiay) {
        this.nhomGiay = nhomGiay;
    }

    /**
     * @return the giaBan
     */
    public double getGiaBan() {
        return giaBan;
    }

    /**
     * @param giaBan the giaBan to set
     */
    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    /**
     * @return the soLuong
     */
    public int getSoLuong() {
        return soLuong;
    }

    /**
     * @param soLuong the soLuong to set
     */
    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }
}
