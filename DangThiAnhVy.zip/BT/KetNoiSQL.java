package BT;

import java.sql.Connection;
import java.sql.DriverManager;

public class KetNoiSQL {
    public static Connection opConnection() throws Exception{
        String dbURL = "jdbc:sqlserver://AV;databaseName=JAVA;user=sa;password=20022012";
        Connection con = DriverManager.getConnection(dbURL);
        return con;
    }
    
}